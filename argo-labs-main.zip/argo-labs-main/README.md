# vote-deploy
Kubernetes Deployment Code for Vote App
